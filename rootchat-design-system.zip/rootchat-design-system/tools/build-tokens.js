// node tools/build-tokens.js  → tokens.css (tokens.json 기준)
const fs = require('fs'); const path = require('path');
const root = path.join(__dirname, '..');
const t = JSON.parse(fs.readFileSync(path.join(root, 'tokens.json'), 'utf8'));
const lines = [];
const walk = (o, pre) => { for (const [k, v] of Object.entries(o)) { if (k.startsWith('$')) continue; const name = pre ? `${pre}-${k}` : k; if (v && typeof v === 'object' && '$value' in v) { const val = v.$value; if (v.$type === 'typography') { lines.push(`  --root-${name}-size:${val.fontSize};`, `  --root-${name}-weight:${val.fontWeight};`, `  --root-${name}-tracking:${val.letterSpacing};`, `  --root-${name}-leading:${val.lineHeight};`); } else if (Array.isArray(val)) lines.push(`  --root-${name}:${val.map(f => /[\s]/.test(f) && !/^-/.test(f) ? `"${f}"` : f).join(',')};`); else lines.push(`  --root-${name}:${val};${v.$description ? ' /* ' + v.$description + ' */' : ''}`); } else if (v && typeof v === 'object') walk(v, name); } };
walk(t.color, ''); walk(t.font, 'font'); walk(t.radius, 'radius'); walk(t.size, 'size');
const css = `/* Root · 루트챗 디자인 토큰: tokens.json에서 생성 (node tools/build-tokens.js). 직접 고치지 마세요. */
@import url("https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css");
:root{
  color-scheme:dark;
${lines.join('\n').replace(/--root-(bg|surface|surface-2|drawer|line|line-strong|text|text-sub|text-placeholder|brand|brand-hover|on-brand|memory|danger|graph-inactive|scroll-thumb|scroll-thumb-hover|scrim|accent-[a-z]+|speaker-\d):/g, (m) => m)}
}
html{background:var(--root-bg);color:var(--root-text);font-family:var(--root-font-family-base);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;word-break:keep-all;letter-spacing:-.005em;scrollbar-width:thin;scrollbar-color:var(--root-scroll-thumb) transparent}
:focus-visible{outline:2px solid var(--root-text);outline-offset:2px}
@media (hover:hover) and (pointer:fine){
  ::-webkit-scrollbar{width:12px;height:12px}
  ::-webkit-scrollbar-track{background:transparent}
  ::-webkit-scrollbar-thumb{background:var(--root-scroll-thumb);border-radius:8px;border:3px solid var(--root-bg);min-height:40px}
  ::-webkit-scrollbar-thumb:hover{background:var(--root-scroll-thumb-hover)}
}
`;
fs.writeFileSync(path.join(root, 'tokens.css'), css);
console.log('tokens.css', lines.length, 'vars');
