// node tools/build-artboard.js → artboard.html (screens/manifest.json 기준)
const fs = require('fs'); const path = require('path');
const root = path.join(__dirname, '..');
const m = JSON.parse(fs.readFileSync(path.join(root, 'screens/manifest.json'), 'utf8'));
const groups = [...new Set(m.screens.map(s => s.group))];
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const sec = groups.map(g => {
  const items = m.screens.filter(s => s.group === g);
  return `<section><h2>${esc(g)} <span>${items.length}</span></h2><div class="row">${items.map(s => `
<figure style="width:${s.width}px"><figcaption><b>${esc(s.name)}</b><span>${s.width === 390 ? '모바일 390' : '데스크톱 1440'}${s.route ? ' · ' + esc(s.route) : ''}</span><a href="${s.file}" target="_blank">열기</a></figcaption><iframe src="${s.file}" width="${s.width}" height="${s.height}" loading="lazy" title="${esc(s.name)}"></iframe></figure>`).join('')}</div></section>`;
}).join('\n');
const html = `<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Root · 루트챗 아트보드</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css"/>
<style>
*{box-sizing:border-box;margin:0;padding:0}
html{background:#0D0C0B;color:#ECE8E1;font-family:'Pretendard Variable',Pretendard,sans-serif;-webkit-font-smoothing:antialiased;letter-spacing:-.005em;scrollbar-width:thin;scrollbar-color:#3A3734 transparent}
::-webkit-scrollbar{width:12px;height:12px}::-webkit-scrollbar-thumb{background:#3A3734;border-radius:8px;border:3px solid #0D0C0B}::-webkit-scrollbar-thumb:hover{background:#4A4641}::-webkit-scrollbar-track{background:transparent}
header{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:16px;min-height:60px;padding:10px 32px;flex-wrap:wrap;background:#131211;border-bottom:1px solid #2C2A27}
header b{font-size:20px;font-weight:800;letter-spacing:-.04em;white-space:nowrap}
header .sub{font-size:14px;color:#B5AFA6;white-space:nowrap}
header nav{display:flex;gap:6px;flex-wrap:wrap}
header nav a,header .z button{height:32px;padding:0 12px;border-radius:16px;background:#1D1C1A;color:#B5AFA6;font-size:13px;font-weight:500;font-family:inherit;white-space:nowrap;border:0;display:flex;align-items:center;text-decoration:none;cursor:pointer}
header .z{display:flex;gap:4px;margin-left:auto}
header .z button.on{background:#ECE8E1;color:#131211;font-weight:600}
main{padding:40px 32px 120px;zoom:var(--z,.5)}
section{margin-bottom:96px}
h2{font-size:40px;font-weight:700;letter-spacing:-.02em;margin-bottom:28px}
h2 span{font-size:24px;color:#9C968D;font-weight:500;margin-left:8px}
.row{display:flex;flex-wrap:wrap;gap:64px 48px;align-items:flex-start}
figure{flex:none}
figcaption{display:flex;align-items:baseline;gap:12px;margin-bottom:14px;font-size:22px}
figcaption b{font-weight:600}
figcaption span{color:#9C968D;font-size:18px}
figcaption a{margin-left:auto;color:#B5AFA6;font-size:18px}
iframe{display:block;border:1px solid #2C2A27;background:#131211}
</style></head><body>
<header><b>루트챗</b><span class="sub">아트보드 · 화면 ${m.screens.length}개</span>
<nav>${groups.map((g, i) => `<a href="#g${i}">${esc(g)}</a>`).join('')}<a href="DESIGN.md">DESIGN.md</a></nav><div class="z">${[25, 50, 75, 100].map(z => `<button data-z="${z / 100}"${z === 50 ? ' class="on"' : ''}>${z}%</button>`).join('')}</div></header>
<main>${sec.replace(/<section>/g, () => `<section id="g${sec.indexOf ? '' : ''}">`)}</main>
<script>
document.querySelectorAll('main section').forEach((s,i)=>s.id='g'+i);
document.querySelectorAll('.z button').forEach(b=>b.onclick=()=>{document.querySelector('main').style.setProperty('--z',b.dataset.z);document.querySelectorAll('.z button').forEach(x=>x.classList.toggle('on',x===b));});
</script>
</body></html>`;
fs.writeFileSync(path.join(root, 'artboard.html'), html);
console.log('artboard.html', m.screens.length, 'screens');
