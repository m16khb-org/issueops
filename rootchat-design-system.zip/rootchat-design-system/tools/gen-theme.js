// Generates root-theme.css: drop-in override for rootchat.me production CSS.
// usage: node gen-theme.js prod.css semantic.css > root-theme.css
const fs = require('fs');
const [prodPath, semPath] = process.argv.slice(2);
const css = fs.readFileSync(prodPath, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');

// --- tiny CSS parser (handles nested at-rules) ---
function parse(s) {
  let i = 0;
  function block() {
    const out = [];
    while (i < s.length) {
      if (s[i] === '}') { i++; return out; }
      let j = i, depth = 0, q = null;
      while (j < s.length) { const c = s[j]; if (q) { if (c === q && s[j-1] !== '\\') q = null; } else if (c === '"' || c === "'") q = c; else if (c === '(') depth++; else if (c === ')') depth--; else if (depth === 0 && (c === '{' || c === ';' || c === '}')) break; j++; }
      const head = s.slice(i, j).trim();
      if (s[j] === ';') { i = j + 1; if (head) out.push({ type: 'stmt', text: head }); continue; }
      if (s[j] === '}') { i = j; if (head) out.push({ type: 'stmt', text: head }); continue; }
      i = j + 1;
      if (head.startsWith('@')) {
        if (/^@(media|supports|container|layer|scope)/.test(head)) out.push({ type: 'at', head, kids: block() });
        else { // keyframes/font-face/property: skip body
          let d = 1; while (i < s.length && d) { if (s[i] === '{') d++; else if (s[i] === '}') d--; i++; }
        }
      } else {
        let k = i, d = 0, q2 = null; while (k < s.length) { const c = s[k]; if (q2) { if (c === q2 && s[k-1] !== '\\') q2 = null; } else if (c === '"' || c === "'") q2 = c; else if (c === '(') d++; else if (c === ')') d--; else if (d === 0 && c === '}') break; k++; }
        out.push({ type: 'rule', sel: head, body: s.slice(i, k) }); i = k + 1;
      }
    }
    return out;
  }
  return block();
}
function decls(body) {
  const out = []; let cur = '', d = 0, q = null;
  for (const c of body) { if (q) { if (c === q) q = null; cur += c; continue; } if (c === '"' || c === "'") { q = c; cur += c; continue; } if (c === '(') d++; if (c === ')') d--; if (c === ';' && d === 0) { out.push(cur); cur = ''; } else cur += c; }
  if (cur.trim()) out.push(cur);
  return out.map(x => { const k = x.indexOf(':'); return [x.slice(0, k).trim(), x.slice(k + 1).trim()]; }).filter(x => x[0]);
}

const STATE = /:hover|:active|:checked|aria-current|aria-expanded|aria-pressed|is-selected|data-active=true|data-state=speaking|:focus/;
function transform(sel, ds) {
  const out = [];
  const isState = STATE.test(sel);
  const isScroll = /::-webkit-scrollbar/.test(sel);
  for (let [p, v] of ds) {
    if (p.startsWith('--')) continue;
    let nv = v;
    if (isScroll) {
      if (/background/.test(p) && /--color-ink\b/.test(v)) nv = '#3A3734';
      else if (/background/.test(p) && /line-soft/.test(v)) nv = 'transparent';
      else if (/^(inline-size|block-size|width|height)$/.test(p)) nv = '12px';
    } else if (p === 'scrollbar-color') nv = '#3A3734 transparent';
    else if (/^(border|outline)/.test(p) && /var\(--color-ink\)/.test(v) && !/radius/.test(p)) {
      nv = v.replace(/var\(--color-ink\)/g, isState ? 'var(--root-line-strong)' : 'var(--root-line)').replace(/\b[23]px solid/, '1px solid');
    } else if (/^border/.test(p) && /\b[23]px solid var\(--color-line-soft\)/.test(v)) nv = v.replace(/\b[23]px solid/, '1px solid');
    else if (p === 'box-shadow' && v !== 'none' && !/--color-focus/.test(v)) nv = 'none';
    else if (p === 'transform' && /:hover|:active/.test(sel) && /translate/.test(v)) nv = 'none';
    else if (p === 'font-weight' && /^(900|800)$/.test(v)) nv = /wordmark/.test(sel) ? '800' : (v === '900' ? '700' : '600');
    else if (p === 'background-image' && /radial-gradient\(var\(--color-ink\)/.test(v)) nv = 'none';
    else if (p === 'font-family' && /--font-mono/.test(v) && /eyebrow|label|badge/.test(sel)) nv = 'var(--font-ui)';
    if (nv !== v) out.push(`${p}:${nv}`);
  }
  return out;
}
function emit(nodes, ind = '') {
  let s = '';
  for (const n of nodes) {
    if (n.type === 'rule') {
      if (/^:root$/.test(n.sel)) continue;
      const t = transform(n.sel, decls(n.body));
      if (t.length) s += `${ind}${n.sel}{${t.join(';')}}\n`;
    } else if (n.type === 'at') {
      const inner = emit(n.kids, ind + '  ');
      if (inner) s += `${ind}${n.head}{\n${inner}${ind}}\n`;
    }
  }
  return s;
}
const auto = emit(parse(css));
const sem = fs.readFileSync(semPath, 'utf8');
const [tokens, semantic] = sem.split('/*@@SEMANTIC@@*/');
process.stdout.write(`/*!
 * Root 디자인 시스템 · rootchat.me 적용 테마 (root-theme.css)
 * 기존 전역 CSS 뒤에 import 하세요. 기존 변수 이름(--color-*, --font-*, --radius-* ...)을 그대로 덮어씁니다.
 * 1) 토큰  2) 자동 변환(운영 CSS 분석: 테두리·그림자·눌림효과·굵기)  3) 컴포넌트 의미 보정
 * 생성: gen-theme.js: 운영 CSS 구조가 바뀌면 다시 생성하세요.
 */
${tokens.trim()}

/* ---------- 2) 자동 변환: 운영 CSS의 잉크 테두리·오프셋 그림자·눌림 이동·900 굵기 ---------- */
${auto}
/* ---------- 3) 컴포넌트 의미 보정 ---------- */
${semantic.trim()}
`);
